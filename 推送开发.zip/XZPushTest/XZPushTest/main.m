//
//  main.m
//  XZPushTest
//
//  Created by coderXu on 16/9/18.
//  Copyright © 2016年 coderXu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
