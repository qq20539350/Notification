# XZPushTest
大家好，我是徐不同

这是我写的一个iOS10的推送demo，其中包含了本地通知以及远程推送的一些例子。

具体使用以及相关代码的说明，可以查看我的简书。

后续我会补充更多的demo供大家参考~

[徐不同简书主页](http://www.jianshu.com/users/2446e9195d21/latest_articles)

[iOS开发 iOS10推送必看(基础篇)](http://www.jianshu.com/p/f5337e8f336d)

[iOS开发 iOS10推送必看(高阶1)](http://www.jianshu.com/p/3d602a60ca4f)

[iOS开发 iOS10推送必看(高阶2)](http://www.jianshu.com/p/f77d070a8812)


[iOS开发 适配iOS10以及Xcode8](http://www.jianshu.com/p/9756992a35ca)

[iOS开发 支持https请求以及https请求的抓包](http://www.jianshu.com/p/97745be81d64)

绝对原创，如果你喜欢我，可以关注我，谢谢
