//
//  NotificationService.h
//  mytest
//
//  Created by coderXu on 16/9/22.
//  Copyright © 2016年 coderXu. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>
 
@interface NotificationService : UNNotificationServiceExtension

@end
