//
//  NotificationService.h
//  ServiceExtension
//
//  Created by Hong on 16/9/30.
//  Copyright © 2016年 Hong. All rights reserved.
//

#import <UserNotifications/UserNotifications.h>

@interface NotificationService : UNNotificationServiceExtension

@end
