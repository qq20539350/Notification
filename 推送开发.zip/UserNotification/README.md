- 本地推送 
- 操作策略（Category+Action）
- 本地推送-附件
- 远程推送
- 远程推送-附件
- 自定义推送UI

可使用[NWPusher](https://github.com/noodlewerk/NWPusher)与本Demo联调, 发送任意格式的远程通知，只需要导入推送证书的p12文件即可。

详细解析请看[iOS10推送通知](https://github.com/liuyanhongwl/ios_common/blob/master/files/ios10_usernotification.md)和[iOS10推送通知进阶(Notification Extension）](https://github.com/liuyanhongwl/ios_common/blob/master/files/ios10_usernotification_extension.md)

关于调试 extension 时遇到的问题，可以看[这里的解决方法](https://github.com/liuyanhongwl/ios_common/blob/master/files/App-Extension-Tips.md)

